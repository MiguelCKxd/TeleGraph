// @generated from schema/ntgcalls.ntl -- DO NOT EDIT
// NOLINTBEGIN
#include <pybind11/functional.h>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

#include <py_async.hpp>
#include <py_bytes.hpp>
#include <py_callback.hpp>
#include <py_holder.hpp>
#include <py_log.hpp>
#include <py_str.hpp>
#include <ntgcalls/exceptions.hpp>
#include <ntgcalls/ntgcalls.hpp>

namespace py = pybind11;
using namespace ntgcalls::support;

PYBIND11_MODULE(ntgcalls, m, py::mod_gil_not_used()) {
    {
        py::class_<ntgcalls::NTgCalls, py_holder<ntgcalls::NTgCalls>> w(m, "NTgCalls");
        w.def(py::init<>());
        w.def("create_p2p_call", [](ntgcalls::NTgCalls& self,
            int64_t user_id
        ) {
            return async_run([&self,
                user_id
            ] {
                self.create_p2p_call(
                    user_id
                );
            });
        },
            py::arg("user_id")
        );
        w.def("init_exchange", [](ntgcalls::NTgCalls& self,
            int64_t user_id,
            const ntgcalls::p2p::DhConfig& dh_config,
            const std::optional<bytes::binary>& ga_hash
        ) {
            return async_run([&self,
                user_id,
                dh_config,
                ga_hash
            ] {
                return self.init_exchange(
                    user_id,
                    dh_config,
                    ga_hash
                );
            });
        },
            py::arg("user_id"),
            py::arg("dh_config"),
            py::arg("ga_hash")
        );
        w.def("exchange_keys", [](ntgcalls::NTgCalls& self,
            int64_t user_id,
            const bytes::binary& g_a_or_b,
            int64_t fingerprint
        ) {
            return async_run([&self,
                user_id,
                g_a_or_b,
                fingerprint
            ] {
                return self.exchange_keys(
                    user_id,
                    g_a_or_b,
                    fingerprint
                );
            });
        },
            py::arg("user_id"),
            py::arg("g_a_or_b"),
            py::arg("fingerprint")
        );
        w.def("skip_exchange", [](ntgcalls::NTgCalls& self,
            int64_t user_id,
            const bytes::binary& encryption_key,
            bool is_outgoing
        ) {
            return async_run([&self,
                user_id,
                encryption_key,
                is_outgoing
            ] {
                self.skip_exchange(
                    user_id,
                    encryption_key,
                    is_outgoing
                );
            });
        },
            py::arg("user_id"),
            py::arg("encryption_key"),
            py::arg("is_outgoing")
        );
        w.def("connect_p2p", [](ntgcalls::NTgCalls& self,
            int64_t user_id,
            const std::vector<ntgcalls::p2p::RTCServer>& servers,
            const std::vector<std::string>& versions,
            bool p2p_allowed,
            const std::optional<std::string>& custom_parameters
        ) {
            return async_run([&self,
                user_id,
                servers,
                versions,
                p2p_allowed,
                custom_parameters
            ] {
                self.connect_p2p(
                    user_id,
                    servers,
                    versions,
                    p2p_allowed,
                    custom_parameters
                );
            });
        },
            py::arg("user_id"),
            py::arg("servers"),
            py::arg("versions"),
            py::arg("p2p_allowed"),
            py::arg("custom_parameters")
        );
        w.def("create_call", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.create_call(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("init_presentation", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.init_presentation(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("init_conference", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            int64_t user_id,
            const std::optional<bytes::binary>& last_block
        ) {
            return async_run([&self,
                chat_id,
                user_id,
                last_block
            ] {
                return self.init_conference(
                    chat_id,
                    user_id,
                    last_block
                );
            });
        },
            py::arg("chat_id"),
            py::arg("user_id"),
            py::arg("last_block")
        );
        w.def("connect", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            const std::string& params,
            bool is_presentation
        ) {
            return async_run([&self,
                chat_id,
                params,
                is_presentation
            ] {
                self.connect(
                    chat_id,
                    params,
                    is_presentation
                );
            });
        },
            py::arg("chat_id"),
            py::arg("params"),
            py::arg("is_presentation")
        );
        w.def("add_incoming_video", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            int64_t user_id,
            const std::string& endpoint,
            const std::vector<wrtc::models::SsrcGroup>& ssrc_groups
        ) {
            return async_run([&self,
                chat_id,
                user_id,
                endpoint,
                ssrc_groups
            ] {
                return self.add_incoming_video(
                    chat_id,
                    user_id,
                    endpoint,
                    ssrc_groups
                );
            });
        },
            py::arg("chat_id"),
            py::arg("user_id"),
            py::arg("endpoint"),
            py::arg("ssrc_groups")
        );
        w.def("remove_incoming_video", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            const std::string& endpoint
        ) {
            return async_run([&self,
                chat_id,
                endpoint
            ] {
                return self.remove_incoming_video(
                    chat_id,
                    endpoint
                );
            });
        },
            py::arg("chat_id"),
            py::arg("endpoint")
        );
        w.def("set_stream_sources", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            ntgcalls::media::StreamManager::Mode mode,
            const ntgcalls::media::MediaDescription& media
        ) {
            return async_run([&self,
                chat_id,
                mode,
                media
            ] {
                self.set_stream_sources(
                    chat_id,
                    mode,
                    media
                );
            });
        },
            py::arg("chat_id"),
            py::arg("mode"),
            py::arg("media")
        );
        w.def("pause", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.pause(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("resume", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.resume(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("mute", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.mute(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("unmute", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.unmute(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("stop", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                self.stop(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("stop_presentation", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                self.stop_presentation(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("get_emojis_fingerprint", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.get_emojis_fingerprint(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("time", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            ntgcalls::media::StreamManager::Mode mode
        ) {
            return async_run([&self,
                chat_id,
                mode
            ] {
                return self.time(
                    chat_id,
                    mode
                );
            });
        },
            py::arg("chat_id"),
            py::arg("mode")
        );
        w.def("get_state", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.get_state(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("get_call_type", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.get_call_type(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("get_connection_mode", [](ntgcalls::NTgCalls& self,
            int64_t chat_id
        ) {
            return async_run([&self,
                chat_id
            ] {
                return self.get_connection_mode(
                    chat_id
                );
            });
        },
            py::arg("chat_id")
        );
        w.def("cpu_usage", [](ntgcalls::NTgCalls& self
        ) {
            return async_run([&self
            ] {
                return self.cpu_usage(
                );
            });
        }
        );
        w.def_static("ping", &ntgcalls::NTgCalls::ping,
            py::call_guard<py::gil_scoped_release>()
        );
        w.def_static("get_media_devices", &ntgcalls::NTgCalls::get_media_devices,
            py::call_guard<py::gil_scoped_release>()
        );
        w.def_static("get_protocol", &ntgcalls::NTgCalls::get_protocol,
            py::call_guard<py::gil_scoped_release>()
        );
        w.def_static("enable_glib_loop", &ntgcalls::NTgCalls::enable_glib_loop,
            py::arg("enable"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_upgrade", finalize_safe(&ntgcalls::NTgCalls::on_upgrade),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_stream_end", finalize_safe(&ntgcalls::NTgCalls::on_stream_end),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_connection_change", finalize_safe(&ntgcalls::NTgCalls::on_connection_change),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_frames", finalize_safe(&ntgcalls::NTgCalls::on_frames),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_signaling_data", finalize_safe(&ntgcalls::NTgCalls::on_signaling_data),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_remote_source_change", finalize_safe(&ntgcalls::NTgCalls::on_remote_source_change),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_request_broadcast_part", finalize_safe(&ntgcalls::NTgCalls::on_request_broadcast_part),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_request_broadcast_timestamp", finalize_safe(&ntgcalls::NTgCalls::on_request_broadcast_timestamp),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_request_participants", finalize_safe(&ntgcalls::NTgCalls::on_request_participants),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_outbound_block", finalize_safe(&ntgcalls::NTgCalls::on_outbound_block),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_subchain_request", finalize_safe(&ntgcalls::NTgCalls::on_subchain_request),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("on_update_emojis", finalize_safe(&ntgcalls::NTgCalls::on_update_emojis),
            py::arg("callback"),
            py::call_guard<py::gil_scoped_release>()
        );
        w.def("send_broadcast_timestamp", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            int64_t timestamp
        ) {
            return async_run([&self,
                chat_id,
                timestamp
            ] {
                self.send_broadcast_timestamp(
                    chat_id,
                    timestamp
                );
            });
        },
            py::arg("chat_id"),
            py::arg("timestamp")
        );
        w.def("send_broadcast_part", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            int64_t segment_id,
            int32_t part_id,
            wrtc::models::MediaSegment::Part::Status status,
            bool quality_update,
            const std::optional<bytes::binary>& data
        ) {
            return async_run([&self,
                chat_id,
                segment_id,
                part_id,
                status,
                quality_update,
                data
            ] {
                self.send_broadcast_part(
                    chat_id,
                    segment_id,
                    part_id,
                    status,
                    quality_update,
                    data
                );
            });
        },
            py::arg("chat_id"),
            py::arg("segment_id"),
            py::arg("part_id"),
            py::arg("status"),
            py::arg("quality_update"),
            py::arg("data")
        );
        w.def("send_signaling_data", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            const bytes::binary& msg_key
        ) {
            return async_run([&self,
                chat_id,
                msg_key
            ] {
                self.send_signaling_data(
                    chat_id,
                    msg_key
                );
            });
        },
            py::arg("chat_id"),
            py::arg("msg_key")
        );
        w.def("set_source_volume", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            uint32_t ssrc,
            int32_t volume
        ) {
            return async_run([&self,
                chat_id,
                ssrc,
                volume
            ] {
                self.set_source_volume(
                    chat_id,
                    ssrc,
                    volume
                );
            });
        },
            py::arg("chat_id"),
            py::arg("ssrc"),
            py::arg("volume")
        );
        w.def("send_external_frame", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            ntgcalls::media::StreamManager::Device device,
            const bytes::binary& data,
            const wrtc::models::FrameData& frame_data
        ) {
            return async_run([&self,
                chat_id,
                device,
                data,
                frame_data
            ] {
                self.send_external_frame(
                    chat_id,
                    device,
                    data,
                    frame_data
                );
            });
        },
            py::arg("chat_id"),
            py::arg("device"),
            py::arg("data"),
            py::arg("frame_data")
        );
        w.def("update_audio_ssrc_mappings", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            const std::vector<wrtc::models::SsrcMapping>& ssrc_groups
        ) {
            return async_run([&self,
                chat_id,
                ssrc_groups
            ] {
                self.update_audio_ssrc_mappings(
                    chat_id,
                    ssrc_groups
                );
            });
        },
            py::arg("chat_id"),
            py::arg("ssrc_groups")
        );
        w.def("apply_blocks", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            int32_t subchain,
            int32_t next_offset,
            const std::vector<bytes::binary>& blocks,
            bool from_short_poll
        ) {
            return async_run([&self,
                chat_id,
                subchain,
                next_offset,
                blocks,
                from_short_poll
            ] {
                self.apply_blocks(
                    chat_id,
                    subchain,
                    next_offset,
                    blocks,
                    from_short_poll
                );
            });
        },
            py::arg("chat_id"),
            py::arg("subchain"),
            py::arg("next_offset"),
            py::arg("blocks"),
            py::arg("from_short_poll")
        );
        w.def("finish_subchain_request", [](ntgcalls::NTgCalls& self,
            int64_t chat_id,
            int32_t subchain
        ) {
            return async_run([&self,
                chat_id,
                subchain
            ] {
                self.finish_subchain_request(
                    chat_id,
                    subchain
                );
            });
        },
            py::arg("chat_id"),
            py::arg("subchain")
        );
        w.def("calls", [](ntgcalls::NTgCalls& self
        ) {
            return async_run([&self
            ] {
                return self.calls(
                );
            });
        }
        );
    }
    py::enum_<ntgcalls::media::BaseMediaDescription::MediaSource>(m, "MediaSource")
        .value("UNKNOWN", ntgcalls::media::BaseMediaDescription::MediaSource::Unknown)
        .value("FILE", ntgcalls::media::BaseMediaDescription::MediaSource::File)
        .value("SHELL", ntgcalls::media::BaseMediaDescription::MediaSource::Shell)
        .value("FFMPEG", ntgcalls::media::BaseMediaDescription::MediaSource::FFmpeg)
        .value("DEVICE", ntgcalls::media::BaseMediaDescription::MediaSource::Device)
        .value("DESKTOP", ntgcalls::media::BaseMediaDescription::MediaSource::Desktop)
        .value("EXTERNAL", ntgcalls::media::BaseMediaDescription::MediaSource::External)
        .export_values();
    py::enum_<ntgcalls::media::StreamManager::Type>(m, "StreamType")
        .value("AUDIO", ntgcalls::media::StreamManager::Type::Audio)
        .value("VIDEO", ntgcalls::media::StreamManager::Type::Video)
        .export_values();
    py::enum_<ntgcalls::media::StreamManager::Status>(m, "StreamStatus")
        .value("ACTIVE", ntgcalls::media::StreamManager::Status::Active)
        .value("PAUSED", ntgcalls::media::StreamManager::Status::Paused)
        .value("IDLING", ntgcalls::media::StreamManager::Status::Idling)
        .export_values();
    py::enum_<ntgcalls::media::StreamManager::Mode>(m, "StreamMode")
        .value("CAPTURE", ntgcalls::media::StreamManager::Mode::Capture)
        .value("PLAYBACK", ntgcalls::media::StreamManager::Mode::Playback)
        .export_values();
    py::enum_<ntgcalls::media::StreamManager::Device>(m, "StreamDevice")
        .value("MICROPHONE", ntgcalls::media::StreamManager::Device::Microphone)
        .value("SPEAKER", ntgcalls::media::StreamManager::Device::Speaker)
        .value("CAMERA", ntgcalls::media::StreamManager::Device::Camera)
        .value("SCREEN", ntgcalls::media::StreamManager::Device::Screen)
        .export_values();
    py::enum_<ntgcalls::ConnectionInfo::State>(m, "ConnectionState")
        .value("CONNECTING", ntgcalls::ConnectionInfo::State::Connecting)
        .value("CONNECTED", ntgcalls::ConnectionInfo::State::Connected)
        .value("FAILED", ntgcalls::ConnectionInfo::State::Failed)
        .value("TIMEOUT", ntgcalls::ConnectionInfo::State::Timeout)
        .value("CLOSED", ntgcalls::ConnectionInfo::State::Closed)
        .export_values();
    py::enum_<ntgcalls::ConnectionInfo::Kind>(m, "ConnectionKind")
        .value("NORMAL", ntgcalls::ConnectionInfo::Kind::Normal)
        .value("PRESENTATION", ntgcalls::ConnectionInfo::Kind::Presentation)
        .export_values();
    py::enum_<ntgcalls::instances::CallInterface::Type>(m, "CallType")
        .value("GROUP", ntgcalls::instances::CallInterface::Type::Group)
        .value("OUTGOING", ntgcalls::instances::CallInterface::Type::Outgoing)
        .value("INCOMING", ntgcalls::instances::CallInterface::Type::Incoming)
        .value("P2P", ntgcalls::instances::CallInterface::Type::P2P)
        .value("CONFERENCE", ntgcalls::instances::CallInterface::Type::Conference)
        .export_values();
    py::enum_<wrtc::models::MediaSegment::Quality>(m, "MediaSegmentQuality")
        .value("NONE", wrtc::models::MediaSegment::Quality::None)
        .value("THUMBNAIL", wrtc::models::MediaSegment::Quality::Thumbnail)
        .value("MEDIUM", wrtc::models::MediaSegment::Quality::Medium)
        .value("FULL", wrtc::models::MediaSegment::Quality::Full)
        .export_values();
    py::enum_<wrtc::models::MediaSegment::Part::Status>(m, "MediaSegmentPartStatus")
        .value("NOT_READY", wrtc::models::MediaSegment::Part::Status::NotReady)
        .value("RESYNC_NEEDED", wrtc::models::MediaSegment::Part::Status::ResyncNeeded)
        .value("DOWNLOADING", wrtc::models::MediaSegment::Part::Status::Downloading)
        .value("SUCCESS", wrtc::models::MediaSegment::Part::Status::Success)
        .export_values();
    py::enum_<wrtc::ConnectionMode>(m, "ConnectionMode")
        .value("NONE", wrtc::ConnectionMode::None)
        .value("RTC", wrtc::ConnectionMode::Rtc)
        .value("STREAM", wrtc::ConnectionMode::Stream)
        .value("RTMP", wrtc::ConnectionMode::Rtmp)
        .export_values();
    py::enum_<webrtc::VideoRotation>(m, "VideoRotation")
        .value("VIDEO_ROTATION_0", webrtc::VideoRotation::kVideoRotation_0)
        .value("VIDEO_ROTATION_90", webrtc::VideoRotation::kVideoRotation_90)
        .value("VIDEO_ROTATION_180", webrtc::VideoRotation::kVideoRotation_180)
        .value("VIDEO_ROTATION_270", webrtc::VideoRotation::kVideoRotation_270)
        .export_values();
    {
        py::class_<ntgcalls::ConnectionInfo> w(m, "ConnectionInfo");
        w.def(py::init<
            ntgcalls::ConnectionInfo::State,
            ntgcalls::ConnectionInfo::Kind
        >(),
            py::arg("state"),
            py::arg("kind")
        );
        w.def_readwrite("state", &ntgcalls::ConnectionInfo::state);
        w.def_readwrite("kind", &ntgcalls::ConnectionInfo::kind);
    }
    {
        py::class_<ntgcalls::RemoteSource> w(m, "RemoteSource");
        w.def(py::init<>());
        w.def(py::init<
            uint32_t,
            ntgcalls::media::StreamManager::Status,
            ntgcalls::media::StreamManager::Device
        >(),
            py::arg("ssrc"),
            py::arg("state"),
            py::arg("device")
        );
        w.def_readwrite("ssrc", &ntgcalls::RemoteSource::ssrc);
        w.def_readwrite("state", &ntgcalls::RemoteSource::state);
        w.def_readwrite("device", &ntgcalls::RemoteSource::device);
    }
    {
        py::class_<ntgcalls::e2e::SubchainRequest> w(m, "SubchainRequest");
        w.def(py::init<>());
        w.def(py::init<
            int32_t,
            int32_t,
            int32_t
        >(),
            py::arg("subchain"),
            py::arg("height"),
            py::arg("limit")
        );
        w.def_readwrite("subchain", &ntgcalls::e2e::SubchainRequest::subchain);
        w.def_readwrite("height", &ntgcalls::e2e::SubchainRequest::height);
        w.def_readwrite("limit", &ntgcalls::e2e::SubchainRequest::limit);
    }
    {
        py::class_<ntgcalls::media::AudioDescription> w(m, "AudioDescription");
        w.def(py::init<
            ntgcalls::media::BaseMediaDescription::MediaSource,
            uint32_t,
            uint8_t,
            std::string,
            bool
        >(),
            py::arg("media_source"),
            py::arg("sample_rate"),
            py::arg("channel_count"),
            py::arg("input"),
            py::arg("keep_open")
        );
        w.def_readwrite("media_source", &ntgcalls::media::AudioDescription::media_source);
        w.def_readwrite("sample_rate", &ntgcalls::media::AudioDescription::sample_rate);
        w.def_readwrite("channel_count", &ntgcalls::media::AudioDescription::channel_count);
        w.def_readwrite("input", &ntgcalls::media::AudioDescription::input);
        w.def_readwrite("keep_open", &ntgcalls::media::AudioDescription::keep_open);
    }
    {
        py::class_<ntgcalls::media::StreamManager::CallInfo> w(m, "CallInfo");
        w.def(py::init<>());
        w.def(py::init<
            ntgcalls::media::StreamManager::Status,
            ntgcalls::media::StreamManager::Status
        >(),
            py::arg("playback"),
            py::arg("capture")
        );
        w.def_readwrite("playback", &ntgcalls::media::StreamManager::CallInfo::playback);
        w.def_readwrite("capture", &ntgcalls::media::StreamManager::CallInfo::capture);
    }
    {
        py::class_<ntgcalls::media::devices::DeviceInfo> w(m, "DeviceInfo");
        w.def(py::init<
            std::string,
            std::string
        >(),
            py::arg("name"),
            py::arg("metadata")
        );
        w.def_readwrite("name", &ntgcalls::media::devices::DeviceInfo::name);
        w.def_readwrite("metadata", &ntgcalls::media::devices::DeviceInfo::metadata);
    }
    {
        py::class_<ntgcalls::media::devices::MediaDevices> w(m, "MediaDevices");
        w.def(py::init<>());
        w.def(py::init<
            std::vector<ntgcalls::media::devices::DeviceInfo>,
            std::vector<ntgcalls::media::devices::DeviceInfo>,
            std::vector<ntgcalls::media::devices::DeviceInfo>,
            std::vector<ntgcalls::media::devices::DeviceInfo>
        >(),
            py::arg("microphone"),
            py::arg("speaker"),
            py::arg("camera"),
            py::arg("screen")
        );
        w.def_readwrite("microphone", &ntgcalls::media::devices::MediaDevices::microphone);
        w.def_readwrite("speaker", &ntgcalls::media::devices::MediaDevices::speaker);
        w.def_readwrite("camera", &ntgcalls::media::devices::MediaDevices::camera);
        w.def_readwrite("screen", &ntgcalls::media::devices::MediaDevices::screen);
    }
    {
        py::class_<ntgcalls::media::MediaState> w(m, "MediaState");
        w.def(py::init<>());
        w.def(py::init<
            bool,
            bool,
            bool,
            bool,
            bool
        >(),
            py::arg("muted"),
            py::arg("video_paused"),
            py::arg("video_stopped"),
            py::arg("presentation_paused"),
            py::arg("presentation_stopped")
        );
        w.def_readwrite("muted", &ntgcalls::media::MediaState::muted);
        w.def_readwrite("video_paused", &ntgcalls::media::MediaState::video_paused);
        w.def_readwrite("video_stopped", &ntgcalls::media::MediaState::video_stopped);
        w.def_readwrite("presentation_paused", &ntgcalls::media::MediaState::presentation_paused);
        w.def_readwrite("presentation_stopped", &ntgcalls::media::MediaState::presentation_stopped);
    }
    {
        py::class_<ntgcalls::media::VideoDescription> w(m, "VideoDescription");
        w.def(py::init<
            ntgcalls::media::BaseMediaDescription::MediaSource,
            int16_t,
            int16_t,
            uint8_t,
            std::string,
            bool
        >(),
            py::arg("media_source"),
            py::arg("width"),
            py::arg("height"),
            py::arg("fps"),
            py::arg("input"),
            py::arg("keep_open")
        );
        w.def_readwrite("media_source", &ntgcalls::media::VideoDescription::media_source);
        w.def_readwrite("width", &ntgcalls::media::VideoDescription::width);
        w.def_readwrite("height", &ntgcalls::media::VideoDescription::height);
        w.def_readwrite("fps", &ntgcalls::media::VideoDescription::fps);
        w.def_readwrite("input", &ntgcalls::media::VideoDescription::input);
        w.def_readwrite("keep_open", &ntgcalls::media::VideoDescription::keep_open);
    }
    {
        py::class_<ntgcalls::media::MediaDescription> w(m, "MediaDescription");
        w.def(py::init<
            std::optional<ntgcalls::media::AudioDescription>,
            std::optional<ntgcalls::media::AudioDescription>,
            std::optional<ntgcalls::media::VideoDescription>,
            std::optional<ntgcalls::media::VideoDescription>
        >(),
            py::arg("microphone"),
            py::arg("speaker"),
            py::arg("camera"),
            py::arg("screen")
        );
        w.def_readwrite("microphone", &ntgcalls::media::MediaDescription::microphone);
        w.def_readwrite("speaker", &ntgcalls::media::MediaDescription::speaker);
        w.def_readwrite("camera", &ntgcalls::media::MediaDescription::camera);
        w.def_readwrite("screen", &ntgcalls::media::MediaDescription::screen);
    }
    {
        py::class_<wrtc::models::FrameData> w(m, "FrameData");
        w.def(py::init<>());
        w.def(py::init<
            int64_t,
            webrtc::VideoRotation,
            uint16_t,
            uint16_t
        >(),
            py::arg("absolute_capture_timestamp_ms"),
            py::arg("rotation"),
            py::arg("width"),
            py::arg("height")
        );
        w.def_readwrite("absolute_capture_timestamp_ms", &wrtc::models::FrameData::absolute_capture_timestamp_ms);
        w.def_readwrite("rotation", &wrtc::models::FrameData::rotation);
        w.def_readwrite("width", &wrtc::models::FrameData::width);
        w.def_readwrite("height", &wrtc::models::FrameData::height);
    }
    {
        py::class_<wrtc::models::ParticipantsRequest> w(m, "ParticipantsRequest");
        w.def(py::init<>());
        w.def(py::init<
            std::vector<uint32_t>
        >(),
            py::arg("ssrcs")
        );
        w.def_readwrite("ssrcs", &wrtc::models::ParticipantsRequest::ssrcs);
    }
    {
        py::class_<wrtc::models::SsrcGroup> w(m, "SsrcGroup");
        w.def(py::init<>());
        w.def(py::init<
            std::string,
            std::vector<uint32_t>
        >(),
            py::arg("semantics"),
            py::arg("ssrcs")
        );
        w.def_readwrite("semantics", &wrtc::models::SsrcGroup::semantics);
        w.def_readwrite("ssrcs", &wrtc::models::SsrcGroup::ssrcs);
    }
    {
        py::class_<wrtc::models::Frame> w(m, "Frame");
        w.def(py::init<
            int64_t,
            bytes::binary,
            wrtc::models::FrameData
        >(),
            py::arg("ssrc"),
            py::arg("data"),
            py::arg("frame_data")
        );
        w.def_readwrite("ssrc", &wrtc::models::Frame::ssrc);
        w.def_readwrite("data", &wrtc::models::Frame::data);
        w.def_readwrite("frame_data", &wrtc::models::Frame::frame_data);
    }
    {
        py::class_<wrtc::models::SegmentPartRequest> w(m, "SegmentPartRequest");
        w.def(py::init<
            int64_t,
            int32_t,
            int32_t,
            int64_t,
            bool,
            int32_t,
            wrtc::models::MediaSegment::Quality
        >(),
            py::arg("segment_id"),
            py::arg("part_id"),
            py::arg("limit"),
            py::arg("timestamp"),
            py::arg("quality_update"),
            py::arg("channel_id"),
            py::arg("quality")
        );
        w.def_readwrite("segment_id", &wrtc::models::SegmentPartRequest::segment_id);
        w.def_readwrite("part_id", &wrtc::models::SegmentPartRequest::part_id);
        w.def_readwrite("limit", &wrtc::models::SegmentPartRequest::limit);
        w.def_readwrite("timestamp", &wrtc::models::SegmentPartRequest::timestamp);
        w.def_readwrite("quality_update", &wrtc::models::SegmentPartRequest::quality_update);
        w.def_readwrite("channel_id", &wrtc::models::SegmentPartRequest::channel_id);
        w.def_readwrite("quality", &wrtc::models::SegmentPartRequest::quality);
    }
    {
        py::class_<wrtc::models::SsrcMapping> w(m, "SsrcMapping");
        w.def(py::init<
            int64_t,
            int32_t
        >(),
            py::arg("user_id"),
            py::arg("ssrc")
        );
        w.def_readwrite("user_id", &wrtc::models::SsrcMapping::user_id);
        w.def_readwrite("ssrc", &wrtc::models::SsrcMapping::ssrc);
    }
    {
        py::class_<ntgcalls::p2p::AuthParams> w(m, "AuthParams");
        w.def(py::init<>());
        w.def(py::init<
            int64_t,
            bytes::binary
        >(),
            py::arg("key_fingerprint"),
            py::arg("g_a_or_b")
        );
        w.def_readwrite("key_fingerprint", &ntgcalls::p2p::AuthParams::key_fingerprint);
        w.def_readwrite("g_a_or_b", &ntgcalls::p2p::AuthParams::g_a_or_b);
    }
    {
        py::class_<ntgcalls::p2p::ConferenceJoinParams> w(m, "ConferenceJoinParams");
        w.def(py::init<>());
        w.def(py::init<
            std::string,
            bytes::binary,
            bytes::binary
        >(),
            py::arg("payload"),
            py::arg("public_key"),
            py::arg("block")
        );
        w.def_readwrite("payload", &ntgcalls::p2p::ConferenceJoinParams::payload);
        w.def_readwrite("public_key", &ntgcalls::p2p::ConferenceJoinParams::public_key);
        w.def_readwrite("block", &ntgcalls::p2p::ConferenceJoinParams::block);
    }
    {
        py::class_<ntgcalls::p2p::DhConfig> w(m, "DhConfig");
        w.def(py::init<
            int32_t,
            bytes::binary,
            bytes::binary
        >(),
            py::arg("g"),
            py::arg("p"),
            py::arg("random")
        );
        w.def_readwrite("g", &ntgcalls::p2p::DhConfig::g);
        w.def_readwrite("p", &ntgcalls::p2p::DhConfig::p);
        w.def_readwrite("random", &ntgcalls::p2p::DhConfig::random);
    }
    {
        py::class_<ntgcalls::p2p::Protocol> w(m, "Protocol");
        w.def(py::init<>());
        w.def(py::init<
            int32_t,
            int32_t,
            bool,
            bool,
            std::vector<std::string>
        >(),
            py::arg("min_layer"),
            py::arg("max_layer"),
            py::arg("udp_p2p"),
            py::arg("udp_reflector"),
            py::arg("library_versions")
        );
        w.def_readwrite("min_layer", &ntgcalls::p2p::Protocol::min_layer);
        w.def_readwrite("max_layer", &ntgcalls::p2p::Protocol::max_layer);
        w.def_readwrite("udp_p2p", &ntgcalls::p2p::Protocol::udp_p2p);
        w.def_readwrite("udp_reflector", &ntgcalls::p2p::Protocol::udp_reflector);
        w.def_readwrite("library_versions", &ntgcalls::p2p::Protocol::library_versions);
    }
    {
        py::class_<ntgcalls::p2p::RTCServer> w(m, "RTCServer");
        w.def(py::init<
            uint64_t,
            std::string,
            std::string,
            uint16_t,
            std::optional<std::string>,
            std::optional<std::string>,
            bool,
            bool,
            bool,
            std::optional<bytes::binary>
        >(),
            py::arg("id"),
            py::arg("ipv4"),
            py::arg("ipv6"),
            py::arg("port"),
            py::arg("username"),
            py::arg("password"),
            py::arg("turn"),
            py::arg("stun"),
            py::arg("tcp"),
            py::arg("peer_tag")
        );
        w.def_readwrite("id", &ntgcalls::p2p::RTCServer::id);
        w.def_readwrite("ipv4", &ntgcalls::p2p::RTCServer::ipv4);
        w.def_readwrite("ipv6", &ntgcalls::p2p::RTCServer::ipv6);
        w.def_readwrite("port", &ntgcalls::p2p::RTCServer::port);
        w.def_readwrite("username", &ntgcalls::p2p::RTCServer::username);
        w.def_readwrite("password", &ntgcalls::p2p::RTCServer::password);
        w.def_readwrite("turn", &ntgcalls::p2p::RTCServer::turn);
        w.def_readwrite("stun", &ntgcalls::p2p::RTCServer::stun);
        w.def_readwrite("tcp", &ntgcalls::p2p::RTCServer::tcp);
        w.def_readwrite("peer_tag", &ntgcalls::p2p::RTCServer::peer_tag);
    }
    const py::exception<wrtc::BaseRTCException> baseExc(m, "BaseRTCException");
    py::register_exception<wrtc::RTCException>(m, "RTCException", baseExc);
    py::register_exception<ntgcalls::ConnectionException>(m, "ConnectionException", baseExc);
    py::register_exception<ntgcalls::SignalingException>(m, "SignalingException", baseExc);
    py::register_exception<ntgcalls::MediaException>(m, "MediaException", baseExc);
    py::register_exception<wrtc::SdpParseException>(m, "SdpParseException", baseExc);
    py::register_exception<wrtc::TransportParseException>(m, "TransportParseException", baseExc);
    py::register_exception<ntgcalls::ConnectionNotFound>(m, "ConnectionNotFound", baseExc);
    py::register_exception<ntgcalls::ConnectionError>(m, "ConnectionError", baseExc);
    py::register_exception<ntgcalls::CryptoError>(m, "CryptoError", baseExc);
    py::register_exception<ntgcalls::TelegramServerError>(m, "TelegramServerError", baseExc);
    py::register_exception<ntgcalls::RTCConnectionNeeded>(m, "RTCConnectionNeeded", baseExc);
    py::register_exception<ntgcalls::InvalidParams>(m, "InvalidParams", baseExc);
    py::register_exception<ntgcalls::SignalingError>(m, "SignalingError", baseExc);
    py::register_exception<ntgcalls::SignalingUnsupported>(m, "SignalingUnsupported", baseExc);
    py::register_exception<ntgcalls::FileError>(m, "FileError", baseExc);
    py::register_exception<ntgcalls::FFmpegError>(m, "FFmpegError", baseExc);
    py::register_exception<ntgcalls::ShellError>(m, "ShellError", baseExc);
    py::register_exception<ntgcalls::MediaDeviceError>(m, "MediaDeviceError", baseExc);
    py::register_exception<ntgcalls::RTMPStreamingUnsupported>(m, "RTMPStreamingUnsupported", baseExc);
    install_log_bridge();
    Py_AtExit(&ntgcalls::utils::ShutdownHook::run_all);
    m.attr("__version__") = NTG_VERSION;
}
// NOLINTEND
