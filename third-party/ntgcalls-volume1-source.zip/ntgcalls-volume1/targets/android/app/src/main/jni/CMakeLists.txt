cmake_minimum_required(VERSION 3.22.1)

project("ntgcalls" C CXX)

set(CLANG_BIN_DIR ${DEPS_DIR}/clang/bin)
set(CMAKE_AR "${CLANG_BIN_DIR}/llvm-ar")
set(CMAKE_STRIP "${CLANG_BIN_DIR}/llvm-strip")
set(CMAKE_C_COMPILER "${CLANG_BIN_DIR}/clang")
set(CMAKE_CXX_COMPILER "${CLANG_BIN_DIR}/clang++")
set(target_name ${CMAKE_PROJECT_NAME})

include(${NDK_CMAKE_DIR})
include(cmake/FindNTgCalls.cmake)

find_package(Threads REQUIRED)

add_library(${CMAKE_PROJECT_NAME} SHARED
    jni.cpp
    jni_onload.cpp
    java_video_capturer_module_jni.cpp
)

set(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -B ${DEPS_DIR}/clang/bin")
target_compile_options(${CMAKE_PROJECT_NAME} PRIVATE
    "$<$<COMPILE_LANGUAGE:CXX>:-nostdinc++>"
    "$<$<COMPILE_LANGUAGE:CXX>:-isystem${LIBCXX_INCLUDE_DIR}>"
)
target_compile_definitions(${CMAKE_PROJECT_NAME} PRIVATE IS_ANDROID)

target_link_libraries(${CMAKE_PROJECT_NAME} PRIVATE NTgCalls::ntgcalls android log OpenSLES EGL)
target_link_options(${CMAKE_PROJECT_NAME}
    PRIVATE
    -Wl,--undefined-glob=Java_*
)
include(${ANDROID_CMAKE_DIR})
