// Auto-generated from TDLib's e2e_api.tl. DO NOT EDIT.
//
// Source:  https://github.com/tdlib/td/blob/6a46f51bdf5e5052ddae26b61cdf9d4864238442/td/generate/scheme/e2e_api.tl
// Schema:  td@6a46f51

#include <ntgcalls/tl/e2e_api.hpp>

namespace ntgcalls::e2e {
  void HandshakeQR::store(tl::TlWriter& w) const {
    w.store_int256(bob_ephemeral_pk);
    w.store_int256(bob_nonce);
  }

  void HandshakeQR::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  HandshakeQR HandshakeQR::fetch(tl::TlReader& r) {
    HandshakeQR out;
    out.bob_ephemeral_pk = r.fetch_int256();
    out.bob_nonce = r.fetch_int256();
    return out;
  }

  HandshakeQR HandshakeQR::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void HandshakeEncryptedMessage::store(tl::TlWriter& w) const {
    w.store_bytes(bytes::view(message));
  }

  void HandshakeEncryptedMessage::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  HandshakeEncryptedMessage HandshakeEncryptedMessage::fetch(tl::TlReader& r) {
    HandshakeEncryptedMessage out;
    out.message = r.fetch_bytes();
    return out;
  }

  HandshakeEncryptedMessage HandshakeEncryptedMessage::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void HandshakeLoginExport::store(tl::TlWriter& w) const {
    w.store_bytes(bytes::view(accept));
    w.store_bytes(bytes::view(encrypted_key));
  }

  void HandshakeLoginExport::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  HandshakeLoginExport HandshakeLoginExport::fetch(tl::TlReader& r) {
    HandshakeLoginExport out;
    out.accept = r.fetch_bytes();
    out.encrypted_key = r.fetch_bytes();
    return out;
  }

  HandshakeLoginExport HandshakeLoginExport::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void HandshakePublic::store_boxed(tl::TlWriter& w) const {
    std::visit([&w](const auto& v) {
      v.store_boxed(w);
    }, value);
  }

  HandshakePublic HandshakePublic::fetch_boxed(tl::TlReader& r) {
    HandshakePublic out;
    switch (r.fetch_int32()) {
      case HandshakeQR::kID:
        out.value = HandshakeQR::fetch(r);
        break;
      case HandshakeEncryptedMessage::kID:
        out.value = HandshakeEncryptedMessage::fetch(r);
        break;
      case HandshakeLoginExport::kID:
        out.value = HandshakeLoginExport::fetch(r);
        break;
      default:
        r.set_error();
        break;
    }
    return out;
  }

  void HandshakePrivateAccept::store(tl::TlWriter& w) const {
    w.store_int256(alice_pk);
    w.store_int256(bob_pk);
    w.store_int64(alice_user_id);
    w.store_int64(bob_user_id);
    w.store_int256(alice_nonce);
    w.store_int256(bob_nonce);
  }

  void HandshakePrivateAccept::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  HandshakePrivateAccept HandshakePrivateAccept::fetch(tl::TlReader& r) {
    HandshakePrivateAccept out;
    out.alice_pk = r.fetch_int256();
    out.bob_pk = r.fetch_int256();
    out.alice_user_id = r.fetch_int64();
    out.bob_user_id = r.fetch_int64();
    out.alice_nonce = r.fetch_int256();
    out.bob_nonce = r.fetch_int256();
    return out;
  }

  HandshakePrivateAccept HandshakePrivateAccept::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void HandshakePrivateFinish::store(tl::TlWriter& w) const {
    w.store_int256(alice_pk);
    w.store_int256(bob_pk);
    w.store_int64(alice_user_id);
    w.store_int64(bob_user_id);
    w.store_int256(alice_nonce);
    w.store_int256(bob_nonce);
  }

  void HandshakePrivateFinish::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  HandshakePrivateFinish HandshakePrivateFinish::fetch(tl::TlReader& r) {
    HandshakePrivateFinish out;
    out.alice_pk = r.fetch_int256();
    out.bob_pk = r.fetch_int256();
    out.alice_user_id = r.fetch_int64();
    out.bob_user_id = r.fetch_int64();
    out.alice_nonce = r.fetch_int256();
    out.bob_nonce = r.fetch_int256();
    return out;
  }

  HandshakePrivateFinish HandshakePrivateFinish::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void HandshakePrivate::store_boxed(tl::TlWriter& w) const {
    std::visit([&w](const auto& v) {
      v.store_boxed(w);
    }, value);
  }

  HandshakePrivate HandshakePrivate::fetch_boxed(tl::TlReader& r) {
    HandshakePrivate out;
    switch (r.fetch_int32()) {
      case HandshakePrivateAccept::kID:
        out.value = HandshakePrivateAccept::fetch(r);
        break;
      case HandshakePrivateFinish::kID:
        out.value = HandshakePrivateFinish::fetch(r);
        break;
      default:
        r.set_error();
        break;
    }
    return out;
  }

  void PersonalUserId::store(tl::TlWriter& w) const {
    w.store_int64(user_id);
  }

  void PersonalUserId::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalUserId PersonalUserId::fetch(tl::TlReader& r) {
    PersonalUserId out;
    out.user_id = r.fetch_int64();
    return out;
  }

  PersonalUserId PersonalUserId::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void PersonalName::store(tl::TlWriter& w) const {
    w.store_string(first_name);
    w.store_string(last_name);
  }

  void PersonalName::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalName PersonalName::fetch(tl::TlReader& r) {
    PersonalName out;
    out.first_name = r.fetch_string();
    out.last_name = r.fetch_string();
    return out;
  }

  PersonalName PersonalName::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void PersonalPhoneNumber::store(tl::TlWriter& w) const {
    w.store_string(phone_number);
  }

  void PersonalPhoneNumber::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalPhoneNumber PersonalPhoneNumber::fetch(tl::TlReader& r) {
    PersonalPhoneNumber out;
    out.phone_number = r.fetch_string();
    return out;
  }

  PersonalPhoneNumber PersonalPhoneNumber::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  int32_t PersonalContactState::flags() const {
    int32_t result = 0;
    if (is_contact) {
      result |= 1;
    }
    return result;
  }

  void PersonalContactState::store(tl::TlWriter& w) const {
    w.store_int32(flags());
  }

  void PersonalContactState::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalContactState PersonalContactState::fetch(tl::TlReader& r) {
    PersonalContactState out;
    const int32_t flags = r.fetch_int32();
    out.is_contact = (flags & 1) != 0;
    return out;
  }

  PersonalContactState PersonalContactState::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  int32_t PersonalEmojiNonces::flags() const {
    int32_t result = 0;
    if (self_nonce) {
      result |= 1;
    }
    if (contact_nonce_hash) {
      result |= 2;
    }
    if (contact_nonce) {
      result |= 4;
    }
    return result;
  }

  void PersonalEmojiNonces::store(tl::TlWriter& w) const {
    w.store_int32(flags());
    if (self_nonce) {
      w.store_int256(*self_nonce);
    }
    if (contact_nonce_hash) {
      w.store_int256(*contact_nonce_hash);
    }
    if (contact_nonce) {
      w.store_int256(*contact_nonce);
    }
  }

  void PersonalEmojiNonces::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalEmojiNonces PersonalEmojiNonces::fetch(tl::TlReader& r) {
    PersonalEmojiNonces out;
    const int32_t flags = r.fetch_int32();
    if (flags & 1) {
      out.self_nonce = r.fetch_int256();
    }
    if (flags & 2) {
      out.contact_nonce_hash = r.fetch_int256();
    }
    if (flags & 4) {
      out.contact_nonce = r.fetch_int256();
    }
    return out;
  }

  PersonalEmojiNonces PersonalEmojiNonces::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void Personal::store_boxed(tl::TlWriter& w) const {
    std::visit([&w](const auto& v) {
      v.store_boxed(w);
    }, value);
  }

  Personal Personal::fetch_boxed(tl::TlReader& r) {
    Personal out;
    switch (r.fetch_int32()) {
      case PersonalUserId::kID:
        out.value = PersonalUserId::fetch(r);
        break;
      case PersonalName::kID:
        out.value = PersonalName::fetch(r);
        break;
      case PersonalPhoneNumber::kID:
        out.value = PersonalPhoneNumber::fetch(r);
        break;
      case PersonalContactState::kID:
        out.value = PersonalContactState::fetch(r);
        break;
      case PersonalEmojiNonces::kID:
        out.value = PersonalEmojiNonces::fetch(r);
        break;
      default:
        r.set_error();
        break;
    }
    return out;
  }

  void PersonalOnServer::store(tl::TlWriter& w) const {
    w.store_int512(signature);
    w.store_int32(signed_at);
    personal.store_boxed(w);
  }

  void PersonalOnServer::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalOnServer PersonalOnServer::fetch(tl::TlReader& r) {
    PersonalOnServer out;
    out.signature = r.fetch_int512();
    out.signed_at = r.fetch_int32();
    out.personal = Personal::fetch_boxed(r);
    return out;
  }

  PersonalOnServer PersonalOnServer::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void PersonalOnClient::store(tl::TlWriter& w) const {
    w.store_int32(signed_at);
    personal.store_boxed(w);
  }

  void PersonalOnClient::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalOnClient PersonalOnClient::fetch(tl::TlReader& r) {
    PersonalOnClient out;
    out.signed_at = r.fetch_int32();
    out.personal = Personal::fetch_boxed(r);
    return out;
  }

  PersonalOnClient PersonalOnClient::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void PersonalData::store(tl::TlWriter& w) const {
    w.store_int256(public_key);
    w.store_vector_size(static_cast<uint32_t>(data.size()));
    for (const auto& item : data) {
      item.store_boxed(w);
    }
  }

  void PersonalData::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  PersonalData PersonalData::fetch(tl::TlReader& r) {
    PersonalData out;
    out.public_key = r.fetch_int256();
    const auto data_count = r.fetch_vector_size();
    for (uint32_t data_i = 0; data_i < data_count && r.ok(); ++data_i) {
      out.data.push_back(PersonalOnServer::fetch_boxed(r));
    }
    return out;
  }

  PersonalData PersonalData::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void KeyContactByUserId::store(tl::TlWriter& w) const {
    w.store_int64(user_id);
  }

  void KeyContactByUserId::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  KeyContactByUserId KeyContactByUserId::fetch(tl::TlReader& r) {
    KeyContactByUserId out;
    out.user_id = r.fetch_int64();
    return out;
  }

  KeyContactByUserId KeyContactByUserId::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void KeyContactByPublicKey::store(tl::TlWriter& w) const {
    w.store_int256(public_key);
  }

  void KeyContactByPublicKey::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  KeyContactByPublicKey KeyContactByPublicKey::fetch(tl::TlReader& r) {
    KeyContactByPublicKey out;
    out.public_key = r.fetch_int256();
    return out;
  }

  KeyContactByPublicKey KeyContactByPublicKey::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void Key::store_boxed(tl::TlWriter& w) const {
    std::visit([&w](const auto& v) {
      v.store_boxed(w);
    }, value);
  }

  Key Key::fetch_boxed(tl::TlReader& r) {
    Key out;
    switch (r.fetch_int32()) {
      case KeyContactByUserId::kID:
        out.value = KeyContactByUserId::fetch(r);
        break;
      case KeyContactByPublicKey::kID:
        out.value = KeyContactByPublicKey::fetch(r);
        break;
      default:
        r.set_error();
        break;
    }
    return out;
  }

  void ValueContactByUserId::store(tl::TlWriter& w) const {
    w.store_vector_size(static_cast<uint32_t>(public_keys.size()));
    for (const auto& item : public_keys) {
      w.store_int256(item);
    }
  }

  void ValueContactByUserId::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  ValueContactByUserId ValueContactByUserId::fetch(tl::TlReader& r) {
    ValueContactByUserId out;
    const auto public_keys_count = r.fetch_vector_size();
    for (uint32_t public_keys_i = 0; public_keys_i < public_keys_count && r.ok(); ++public_keys_i) {
      out.public_keys.push_back(r.fetch_int256());
    }
    return out;
  }

  ValueContactByUserId ValueContactByUserId::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void ValueContactByPublicKey::store(tl::TlWriter& w) const {
    w.store_vector_size(static_cast<uint32_t>(entries.size()));
    for (const auto& item : entries) {
      item.store_boxed(w);
    }
  }

  void ValueContactByPublicKey::store_boxed(tl::TlWriter& w) const {
    w.store_int32(kID);
    store(w);
  }

  ValueContactByPublicKey ValueContactByPublicKey::fetch(tl::TlReader& r) {
    ValueContactByPublicKey out;
    const auto entries_count = r.fetch_vector_size();
    for (uint32_t entries_i = 0; entries_i < entries_count && r.ok(); ++entries_i) {
      out.entries.push_back(PersonalOnClient::fetch_boxed(r));
    }
    return out;
  }

  ValueContactByPublicKey ValueContactByPublicKey::fetch_boxed(tl::TlReader& r) {
    if (r.fetch_int32() != kID) {
      r.set_error();
      return {};
    }
    return fetch(r);
  }

  void Value::store_boxed(tl::TlWriter& w) const {
    std::visit([&w](const auto& v) {
      v.store_boxed(w);
    }, value);
  }

  Value Value::fetch_boxed(tl::TlReader& r) {
    Value out;
    switch (r.fetch_int32()) {
      case ValueContactByUserId::kID:
        out.value = ValueContactByUserId::fetch(r);
        break;
      case ValueContactByPublicKey::kID:
        out.value = ValueContactByPublicKey::fetch(r);
        break;
      default:
        r.set_error();
        break;
    }
    return out;
  }

  namespace chain {
    void GroupBroadcastNonceCommit::store(tl::TlWriter& w) const {
      w.store_int512(signature);
      w.store_int64(user_id);
      w.store_int32(chain_height);
      w.store_int256(chain_hash);
      w.store_int256(nonce_hash);
    }

    void GroupBroadcastNonceCommit::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    GroupBroadcastNonceCommit GroupBroadcastNonceCommit::fetch(tl::TlReader& r) {
      GroupBroadcastNonceCommit out;
      out.signature = r.fetch_int512();
      out.user_id = r.fetch_int64();
      out.chain_height = r.fetch_int32();
      out.chain_hash = r.fetch_int256();
      out.nonce_hash = r.fetch_int256();
      return out;
    }

    GroupBroadcastNonceCommit GroupBroadcastNonceCommit::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void GroupBroadcastNonceReveal::store(tl::TlWriter& w) const {
      w.store_int512(signature);
      w.store_int64(user_id);
      w.store_int32(chain_height);
      w.store_int256(chain_hash);
      w.store_int256(nonce);
    }

    void GroupBroadcastNonceReveal::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    GroupBroadcastNonceReveal GroupBroadcastNonceReveal::fetch(tl::TlReader& r) {
      GroupBroadcastNonceReveal out;
      out.signature = r.fetch_int512();
      out.user_id = r.fetch_int64();
      out.chain_height = r.fetch_int32();
      out.chain_hash = r.fetch_int256();
      out.nonce = r.fetch_int256();
      return out;
    }

    GroupBroadcastNonceReveal GroupBroadcastNonceReveal::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void GroupBroadcast::store_boxed(tl::TlWriter& w) const {
      std::visit([&w](const auto& v) {
        v.store_boxed(w);
      }, value);
    }

    GroupBroadcast GroupBroadcast::fetch_boxed(tl::TlReader& r) {
      GroupBroadcast out;
      switch (r.fetch_int32()) {
        case GroupBroadcastNonceCommit::kID:
          out.value = GroupBroadcastNonceCommit::fetch(r);
          break;
        case GroupBroadcastNonceReveal::kID:
          out.value = GroupBroadcastNonceReveal::fetch(r);
          break;
        default:
          r.set_error();
          break;
      }
      return out;
    }

    int32_t GroupParticipant::flags() const {
      int32_t result = 0;
      if (add_users) {
        result |= 1;
      }
      if (remove_users) {
        result |= 2;
      }
      return result;
    }

    void GroupParticipant::store(tl::TlWriter& w) const {
      w.store_int64(user_id);
      w.store_int256(public_key);
      w.store_int32(flags());
      w.store_int32(version);
    }

    void GroupParticipant::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    GroupParticipant GroupParticipant::fetch(tl::TlReader& r) {
      GroupParticipant out;
      out.user_id = r.fetch_int64();
      out.public_key = r.fetch_int256();
      const int32_t flags = r.fetch_int32();
      out.add_users = (flags & 1) != 0;
      out.remove_users = (flags & 2) != 0;
      out.version = r.fetch_int32();
      return out;
    }

    GroupParticipant GroupParticipant::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void GroupState::store(tl::TlWriter& w) const {
      w.store_vector_size(static_cast<uint32_t>(participants.size()));
      for (const auto& item : participants) {
        item.store_boxed(w);
      }
      w.store_int32(external_permissions);
    }

    void GroupState::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    GroupState GroupState::fetch(tl::TlReader& r) {
      GroupState out;
      const auto participants_count = r.fetch_vector_size();
      for (uint32_t participants_i = 0; participants_i < participants_count && r.ok(); ++participants_i) {
        out.participants.push_back(GroupParticipant::fetch_boxed(r));
      }
      out.external_permissions = r.fetch_int32();
      return out;
    }

    GroupState GroupState::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void SharedKey::store(tl::TlWriter& w) const {
      w.store_int256(ek);
      w.store_string(encrypted_shared_key);
      w.store_vector_size(static_cast<uint32_t>(dest_user_id.size()));
      for (const auto& item : dest_user_id) {
        w.store_int64(item);
      }
      w.store_vector_size(static_cast<uint32_t>(dest_header.size()));
      for (const auto& item : dest_header) {
        w.store_bytes(bytes::view(item));
      }
    }

    void SharedKey::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    SharedKey SharedKey::fetch(tl::TlReader& r) {
      SharedKey out;
      out.ek = r.fetch_int256();
      out.encrypted_shared_key = r.fetch_string();
      const auto dest_user_id_count = r.fetch_vector_size();
      for (uint32_t dest_user_id_i = 0; dest_user_id_i < dest_user_id_count && r.ok(); ++dest_user_id_i) {
        out.dest_user_id.push_back(r.fetch_int64());
      }
      const auto dest_header_count = r.fetch_vector_size();
      for (uint32_t dest_header_i = 0; dest_header_i < dest_header_count && r.ok(); ++dest_header_i) {
        out.dest_header.push_back(r.fetch_bytes());
      }
      return out;
    }

    SharedKey SharedKey::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void ChangeNoop::store(tl::TlWriter& w) const {
      w.store_int256(nonce);
    }

    void ChangeNoop::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    ChangeNoop ChangeNoop::fetch(tl::TlReader& r) {
      ChangeNoop out;
      out.nonce = r.fetch_int256();
      return out;
    }

    ChangeNoop ChangeNoop::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void ChangeSetValue::store(tl::TlWriter& w) const {
      w.store_bytes(bytes::view(key));
      w.store_bytes(bytes::view(value));
    }

    void ChangeSetValue::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    ChangeSetValue ChangeSetValue::fetch(tl::TlReader& r) {
      ChangeSetValue out;
      out.key = r.fetch_bytes();
      out.value = r.fetch_bytes();
      return out;
    }

    ChangeSetValue ChangeSetValue::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void ChangeSetGroupState::store(tl::TlWriter& w) const {
      group_state.store_boxed(w);
    }

    void ChangeSetGroupState::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    ChangeSetGroupState ChangeSetGroupState::fetch(tl::TlReader& r) {
      ChangeSetGroupState out;
      out.group_state = GroupState::fetch_boxed(r);
      return out;
    }

    ChangeSetGroupState ChangeSetGroupState::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void ChangeSetSharedKey::store(tl::TlWriter& w) const {
      shared_key.store_boxed(w);
    }

    void ChangeSetSharedKey::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    ChangeSetSharedKey ChangeSetSharedKey::fetch(tl::TlReader& r) {
      ChangeSetSharedKey out;
      out.shared_key = SharedKey::fetch_boxed(r);
      return out;
    }

    ChangeSetSharedKey ChangeSetSharedKey::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    void Change::store_boxed(tl::TlWriter& w) const {
      std::visit([&w](const auto& v) {
        v.store_boxed(w);
      }, value);
    }

    Change Change::fetch_boxed(tl::TlReader& r) {
      Change out;
      switch (r.fetch_int32()) {
        case ChangeNoop::kID:
          out.value = ChangeNoop::fetch(r);
          break;
        case ChangeSetValue::kID:
          out.value = ChangeSetValue::fetch(r);
          break;
        case ChangeSetGroupState::kID:
          out.value = ChangeSetGroupState::fetch(r);
          break;
        case ChangeSetSharedKey::kID:
          out.value = ChangeSetSharedKey::fetch(r);
          break;
        default:
          r.set_error();
          break;
      }
      return out;
    }

    int32_t StateProof::flags() const {
      int32_t result = 0;
      if (group_state) {
        result |= 1;
      }
      if (shared_key) {
        result |= 2;
      }
      return result;
    }

    void StateProof::store(tl::TlWriter& w) const {
      w.store_int32(flags());
      w.store_int256(kv_hash);
      if (group_state) {
        group_state->store_boxed(w);
      }
      if (shared_key) {
        shared_key->store_boxed(w);
      }
    }

    void StateProof::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    StateProof StateProof::fetch(tl::TlReader& r) {
      StateProof out;
      const int32_t flags = r.fetch_int32();
      out.kv_hash = r.fetch_int256();
      if (flags & 1) {
        out.group_state = GroupState::fetch_boxed(r);
      }
      if (flags & 2) {
        out.shared_key = SharedKey::fetch_boxed(r);
      }
      return out;
    }

    StateProof StateProof::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }

    int32_t Block::flags() const {
      int32_t result = 0;
      if (signature_public_key) {
        result |= 1;
      }
      return result;
    }

    void Block::store(tl::TlWriter& w) const {
      w.store_int512(signature);
      w.store_int32(flags());
      w.store_int256(prev_block_hash);
      w.store_vector_size(static_cast<uint32_t>(changes.size()));
      for (const auto& item : changes) {
        item.store_boxed(w);
      }
      w.store_int32(height);
      state_proof.store_boxed(w);
      if (signature_public_key) {
        w.store_int256(*signature_public_key);
      }
    }

    void Block::store_boxed(tl::TlWriter& w) const {
      w.store_int32(kID);
      store(w);
    }

    Block Block::fetch(tl::TlReader& r) {
      Block out;
      out.signature = r.fetch_int512();
      const int32_t flags = r.fetch_int32();
      out.prev_block_hash = r.fetch_int256();
      const auto changes_count = r.fetch_vector_size();
      for (uint32_t changes_i = 0; changes_i < changes_count && r.ok(); ++changes_i) {
        out.changes.push_back(Change::fetch_boxed(r));
      }
      out.height = r.fetch_int32();
      out.state_proof = StateProof::fetch_boxed(r);
      if (flags & 1) {
        out.signature_public_key = r.fetch_int256();
      }
      return out;
    }

    Block Block::fetch_boxed(tl::TlReader& r) {
      if (r.fetch_int32() != kID) {
        r.set_error();
        return {};
      }
      return fetch(r);
    }
  } // namespace chain
} // namespace ntgcalls::e2e
