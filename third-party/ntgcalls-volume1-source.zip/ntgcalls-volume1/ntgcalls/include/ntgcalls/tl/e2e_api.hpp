// Auto-generated from TDLib's e2e_api.tl. DO NOT EDIT.
//
// Source:  https://github.com/tdlib/td/blob/6a46f51bdf5e5052ddae26b61cdf9d4864238442/td/generate/scheme/e2e_api.tl
// Schema:  td@6a46f51

#pragma once
#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <variant>
#include <vector>
#include <ntgcalls/tl/tl.hpp>

namespace ntgcalls::e2e {
  struct HandshakeQR {
    static constexpr int32_t kID = static_cast<int32_t>(0xd37da15a);
    bytes::array<32> bob_ephemeral_pk{};
    bytes::array<32> bob_nonce{};
    bool operator==(const HandshakeQR&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakeQR fetch(tl::TlReader& r);
    static HandshakeQR fetch_boxed(tl::TlReader& r);
  };

  struct HandshakeEncryptedMessage {
    static constexpr int32_t kID = static_cast<int32_t>(0x97400efc);
    bytes::binary message{};
    bool operator==(const HandshakeEncryptedMessage&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakeEncryptedMessage fetch(tl::TlReader& r);
    static HandshakeEncryptedMessage fetch_boxed(tl::TlReader& r);
  };

  struct HandshakeLoginExport {
    static constexpr int32_t kID = static_cast<int32_t>(0xf6f07754);
    bytes::binary accept{};
    bytes::binary encrypted_key{};
    bool operator==(const HandshakeLoginExport&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakeLoginExport fetch(tl::TlReader& r);
    static HandshakeLoginExport fetch_boxed(tl::TlReader& r);
  };

  struct HandshakePublic {
    std::variant<HandshakeQR, HandshakeEncryptedMessage, HandshakeLoginExport> value;
    bool operator==(const HandshakePublic&) const = default;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakePublic fetch_boxed(tl::TlReader& r);
  };

  struct HandshakePrivateAccept {
    static constexpr int32_t kID = static_cast<int32_t>(0x99f91557);
    bytes::array<32> alice_pk{};
    bytes::array<32> bob_pk{};
    int64_t alice_user_id{};
    int64_t bob_user_id{};
    bytes::array<32> alice_nonce{};
    bytes::array<32> bob_nonce{};
    bool operator==(const HandshakePrivateAccept&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakePrivateAccept fetch(tl::TlReader& r);
    static HandshakePrivateAccept fetch_boxed(tl::TlReader& r);
  };

  struct HandshakePrivateFinish {
    static constexpr int32_t kID = static_cast<int32_t>(0x15161335);
    bytes::array<32> alice_pk{};
    bytes::array<32> bob_pk{};
    int64_t alice_user_id{};
    int64_t bob_user_id{};
    bytes::array<32> alice_nonce{};
    bytes::array<32> bob_nonce{};
    bool operator==(const HandshakePrivateFinish&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakePrivateFinish fetch(tl::TlReader& r);
    static HandshakePrivateFinish fetch_boxed(tl::TlReader& r);
  };

  struct HandshakePrivate {
    std::variant<HandshakePrivateAccept, HandshakePrivateFinish> value;
    bool operator==(const HandshakePrivate&) const = default;
    void store_boxed(tl::TlWriter& w) const;
    static HandshakePrivate fetch_boxed(tl::TlReader& r);
  };

  struct PersonalUserId {
    static constexpr int32_t kID = static_cast<int32_t>(0x16a7b8e0);
    int64_t user_id{};
    bool operator==(const PersonalUserId&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalUserId fetch(tl::TlReader& r);
    static PersonalUserId fetch_boxed(tl::TlReader& r);
  };

  struct PersonalName {
    static constexpr int32_t kID = static_cast<int32_t>(0x68ea66d5);
    std::string first_name{};
    std::string last_name{};
    bool operator==(const PersonalName&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalName fetch(tl::TlReader& r);
    static PersonalName fetch_boxed(tl::TlReader& r);
  };

  struct PersonalPhoneNumber {
    static constexpr int32_t kID = static_cast<int32_t>(0x4307fe1a);
    std::string phone_number{};
    bool operator==(const PersonalPhoneNumber&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalPhoneNumber fetch(tl::TlReader& r);
    static PersonalPhoneNumber fetch_boxed(tl::TlReader& r);
  };

  struct PersonalContactState {
    static constexpr int32_t kID = static_cast<int32_t>(0xc14ac456);
    bool is_contact{};
    [[nodiscard]] int32_t flags() const;
    bool operator==(const PersonalContactState&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalContactState fetch(tl::TlReader& r);
    static PersonalContactState fetch_boxed(tl::TlReader& r);
  };

  struct PersonalEmojiNonces {
    static constexpr int32_t kID = static_cast<int32_t>(0x85fe42b7);
    std::optional<bytes::array<32>> self_nonce;
    std::optional<bytes::array<32>> contact_nonce_hash;
    std::optional<bytes::array<32>> contact_nonce;
    [[nodiscard]] int32_t flags() const;
    bool operator==(const PersonalEmojiNonces&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalEmojiNonces fetch(tl::TlReader& r);
    static PersonalEmojiNonces fetch_boxed(tl::TlReader& r);
  };

  struct Personal {
    std::variant<PersonalUserId, PersonalName, PersonalPhoneNumber, PersonalContactState, PersonalEmojiNonces> value;
    bool operator==(const Personal&) const = default;
    void store_boxed(tl::TlWriter& w) const;
    static Personal fetch_boxed(tl::TlReader& r);
  };

  struct PersonalOnServer {
    static constexpr int32_t kID = static_cast<int32_t>(0xd04d2c83);
    bytes::array<64> signature{};
    int32_t signed_at{};
    Personal personal;
    bool operator==(const PersonalOnServer&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalOnServer fetch(tl::TlReader& r);
    static PersonalOnServer fetch_boxed(tl::TlReader& r);
  };

  struct PersonalOnClient {
    static constexpr int32_t kID = static_cast<int32_t>(0xeba65211);
    int32_t signed_at{};
    Personal personal;
    bool operator==(const PersonalOnClient&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalOnClient fetch(tl::TlReader& r);
    static PersonalOnClient fetch_boxed(tl::TlReader& r);
  };

  struct PersonalData {
    static constexpr int32_t kID = static_cast<int32_t>(0x3ddb7846);
    bytes::array<32> public_key{};
    std::vector<PersonalOnServer> data;
    bool operator==(const PersonalData&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static PersonalData fetch(tl::TlReader& r);
    static PersonalData fetch_boxed(tl::TlReader& r);
  };

  struct KeyContactByUserId {
    static constexpr int32_t kID = static_cast<int32_t>(0x72c13e2b);
    int64_t user_id{};
    bool operator==(const KeyContactByUserId&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static KeyContactByUserId fetch(tl::TlReader& r);
    static KeyContactByUserId fetch_boxed(tl::TlReader& r);
  };

  struct KeyContactByPublicKey {
    static constexpr int32_t kID = static_cast<int32_t>(0x6c4f8c98);
    bytes::array<32> public_key{};
    bool operator==(const KeyContactByPublicKey&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static KeyContactByPublicKey fetch(tl::TlReader& r);
    static KeyContactByPublicKey fetch_boxed(tl::TlReader& r);
  };

  struct Key {
    std::variant<KeyContactByUserId, KeyContactByPublicKey> value;
    bool operator==(const Key&) const = default;
    void store_boxed(tl::TlWriter& w) const;
    static Key fetch_boxed(tl::TlReader& r);
  };

  struct ValueContactByUserId {
    static constexpr int32_t kID = static_cast<int32_t>(0x06ca0713);
    std::vector<bytes::array<32>> public_keys;
    bool operator==(const ValueContactByUserId&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static ValueContactByUserId fetch(tl::TlReader& r);
    static ValueContactByUserId fetch_boxed(tl::TlReader& r);
  };

  struct ValueContactByPublicKey {
    static constexpr int32_t kID = static_cast<int32_t>(0xab73bae1);
    std::vector<PersonalOnClient> entries;
    bool operator==(const ValueContactByPublicKey&) const = default;
    void store(tl::TlWriter& w) const;
    void store_boxed(tl::TlWriter& w) const;
    static ValueContactByPublicKey fetch(tl::TlReader& r);
    static ValueContactByPublicKey fetch_boxed(tl::TlReader& r);
  };

  struct Value {
    std::variant<ValueContactByUserId, ValueContactByPublicKey> value;
    bool operator==(const Value&) const = default;
    void store_boxed(tl::TlWriter& w) const;
    static Value fetch_boxed(tl::TlReader& r);
  };

  namespace chain {
    struct GroupBroadcastNonceCommit {
      static constexpr int32_t kID = static_cast<int32_t>(0xd1512ae7);
      bytes::array<64> signature{};
      int64_t user_id{};
      int32_t chain_height{};
      bytes::array<32> chain_hash{};
      bytes::array<32> nonce_hash{};
      bool operator==(const GroupBroadcastNonceCommit&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static GroupBroadcastNonceCommit fetch(tl::TlReader& r);
      static GroupBroadcastNonceCommit fetch_boxed(tl::TlReader& r);
    };

    struct GroupBroadcastNonceReveal {
      static constexpr int32_t kID = static_cast<int32_t>(0x83f4f9d8);
      bytes::array<64> signature{};
      int64_t user_id{};
      int32_t chain_height{};
      bytes::array<32> chain_hash{};
      bytes::array<32> nonce{};
      bool operator==(const GroupBroadcastNonceReveal&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static GroupBroadcastNonceReveal fetch(tl::TlReader& r);
      static GroupBroadcastNonceReveal fetch_boxed(tl::TlReader& r);
    };

    struct GroupBroadcast {
      std::variant<GroupBroadcastNonceCommit, GroupBroadcastNonceReveal> value;
      bool operator==(const GroupBroadcast&) const = default;
      void store_boxed(tl::TlWriter& w) const;
      static GroupBroadcast fetch_boxed(tl::TlReader& r);
    };

    struct GroupParticipant {
      static constexpr int32_t kID = static_cast<int32_t>(0x18f3971f);
      int64_t user_id{};
      bytes::array<32> public_key{};
      bool add_users{};
      bool remove_users{};
      int32_t version{};
      [[nodiscard]] int32_t flags() const;
      bool operator==(const GroupParticipant&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static GroupParticipant fetch(tl::TlReader& r);
      static GroupParticipant fetch_boxed(tl::TlReader& r);
    };

    struct GroupState {
      static constexpr int32_t kID = static_cast<int32_t>(0x1ddc7584);
      std::vector<GroupParticipant> participants;
      int32_t external_permissions{};
      bool operator==(const GroupState&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static GroupState fetch(tl::TlReader& r);
      static GroupState fetch_boxed(tl::TlReader& r);
    };

    struct SharedKey {
      static constexpr int32_t kID = static_cast<int32_t>(0x8a847e7f);
      bytes::array<32> ek{};
      std::string encrypted_shared_key{};
      std::vector<int64_t> dest_user_id;
      std::vector<bytes::binary> dest_header;
      bool operator==(const SharedKey&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static SharedKey fetch(tl::TlReader& r);
      static SharedKey fetch_boxed(tl::TlReader& r);
    };

    struct ChangeNoop {
      static constexpr int32_t kID = static_cast<int32_t>(0xdeb4a41b);
      bytes::array<32> nonce{};
      bool operator==(const ChangeNoop&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static ChangeNoop fetch(tl::TlReader& r);
      static ChangeNoop fetch_boxed(tl::TlReader& r);
    };

    struct ChangeSetValue {
      static constexpr int32_t kID = static_cast<int32_t>(0xfe0139cc);
      bytes::binary key{};
      bytes::binary value{};
      bool operator==(const ChangeSetValue&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static ChangeSetValue fetch(tl::TlReader& r);
      static ChangeSetValue fetch_boxed(tl::TlReader& r);
    };

    struct ChangeSetGroupState {
      static constexpr int32_t kID = static_cast<int32_t>(0x2cf17146);
      GroupState group_state;
      bool operator==(const ChangeSetGroupState&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static ChangeSetGroupState fetch(tl::TlReader& r);
      static ChangeSetGroupState fetch_boxed(tl::TlReader& r);
    };

    struct ChangeSetSharedKey {
      static constexpr int32_t kID = static_cast<int32_t>(0x987a2158);
      SharedKey shared_key;
      bool operator==(const ChangeSetSharedKey&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static ChangeSetSharedKey fetch(tl::TlReader& r);
      static ChangeSetSharedKey fetch_boxed(tl::TlReader& r);
    };

    struct Change {
      std::variant<ChangeNoop, ChangeSetValue, ChangeSetGroupState, ChangeSetSharedKey> value;
      bool operator==(const Change&) const = default;
      void store_boxed(tl::TlWriter& w) const;
      static Change fetch_boxed(tl::TlReader& r);
    };

    struct StateProof {
      static constexpr int32_t kID = static_cast<int32_t>(0xd6b679e6);
      bytes::array<32> kv_hash{};
      std::optional<GroupState> group_state;
      std::optional<SharedKey> shared_key;
      [[nodiscard]] int32_t flags() const;
      bool operator==(const StateProof&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static StateProof fetch(tl::TlReader& r);
      static StateProof fetch_boxed(tl::TlReader& r);
    };

    struct Block {
      static constexpr int32_t kID = static_cast<int32_t>(0x639a3db6);
      bytes::array<64> signature{};
      bytes::array<32> prev_block_hash{};
      std::vector<Change> changes;
      int32_t height{};
      StateProof state_proof;
      std::optional<bytes::array<32>> signature_public_key;
      [[nodiscard]] int32_t flags() const;
      bool operator==(const Block&) const = default;
      void store(tl::TlWriter& w) const;
      void store_boxed(tl::TlWriter& w) const;
      static Block fetch(tl::TlReader& r);
      static Block fetch_boxed(tl::TlReader& r);
    };
  } // namespace chain
} // namespace ntgcalls::e2e
