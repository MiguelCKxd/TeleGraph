#pragma once
#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace ntgcalls::media {
inline void apply_source_gain(unsigned char* data, const size_t size, const int gain) {
    if (gain == 10000) return;
    if (gain == 0) { std::memset(data, 0, size); return; }
    // memcpy avoids assuming the input buffer has int16_t alignment.
    for (size_t i = 0; i + sizeof(int16_t) <= size; i += sizeof(int16_t)) {
        int16_t sample;
        std::memcpy(&sample, data + i, sizeof(sample));
        const auto scaled = static_cast<int32_t>(sample) * gain / 10000;
        sample = static_cast<int16_t>(std::clamp(scaled, int32_t(-32768), int32_t(32767)));
        std::memcpy(data + i, &sample, sizeof(sample));
    }
}
}
