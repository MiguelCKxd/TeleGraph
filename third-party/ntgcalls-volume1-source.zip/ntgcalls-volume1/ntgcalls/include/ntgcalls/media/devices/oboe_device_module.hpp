//
// Created by Lauren on 24/04/25.
//

#pragma once

#ifdef IS_ANDROID
#include <ntgcalls/io/audio_mixer.hpp>
#include <ntgcalls/io/base_reader.hpp>
#include <ntgcalls/media/devices/base_device_module.hpp>
#include <oboe/Oboe.h>

namespace ntgcalls::media::devices {

    class OboeDeviceModule;

    class OboeErrorCallback final: public oboe::AudioStreamErrorCallback {
        std::mutex mutex_;
        OboeDeviceModule* owner_;

    public:
        explicit OboeErrorCallback(OboeDeviceModule* owner);

        void detach();

        void onErrorAfterClose(oboe::AudioStream* audio_stream, oboe::Result error) override;
    };

    class OboeDeviceModule final: public BaseDeviceModule, public io::BaseReader, public io::AudioMixer, oboe::AudioStreamDataCallback {
        friend class OboeErrorCallback;

        std::shared_ptr<OboeErrorCallback> error_callback_;
        std::mutex stream_mutex_;
        std::shared_ptr<oboe::AudioStream> stream_;
        std::mutex buffer_mutex_;
        std::vector<uint8_t> buffer_;
        size_t frame_size_ = 0;

        oboe::Result create_stream();

        oboe::Result recreate_stream();

        void restart_stream(const oboe::AudioStream* audio_stream);

    protected:
        void on_data(bytes::unique_binary data) override;

    public:
        OboeDeviceModule(const AudioDescription* desc, bool is_capture, BaseSink* sink);

        ~OboeDeviceModule() override;

        void open() override;

        oboe::DataCallbackResult onAudioReady(oboe::AudioStream* audio_stream, void* audio_data, int32_t num_frames) override;
    };

} // ntgcalls::media::devices
#endif
